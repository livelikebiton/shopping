export class CredentialsModel {
    public email: string;
    public password: string;
}