export class CategoryModel {
    public _id: string;
    public name: string;
}