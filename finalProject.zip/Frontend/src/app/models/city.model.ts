export class CityModel {
    public _id: string;
    public city: string;
}